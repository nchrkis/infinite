import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from scipy.stats import pearsonr
from sklearn.preprocessing import MinMaxScaler

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.optimizers import Adam

# 1. Load the CSV file.
#    The CSV file contains several columns (features).
#    We want to use all of them as input, but we will only predict three target variables.
df = pd.read_csv("path_to_data.csv")

# Define the target variable names.
target_columns = ['temp', 'hum', 'windvel']

# 2. Separate the data into inputs (all features) and targets (a subset of columns).
X_all = df.copy()             # All features are used as input.
y_all = df[target_columns].copy()  # Only these columns are predicted.

# 3. Scale the data.
#    Use one scaler for input features and a separate one for the target variables.
scaler_X = MinMaxScaler()
X_scaled = scaler_X.fit_transform(X_all)

scaler_y = MinMaxScaler()
y_scaled = scaler_y.fit_transform(y_all)

# 4. Create sequences (sliding windows) for time series prediction.
#    For each sample, we use 3 consecutive time steps of *all features* to predict the next time step of the target variables.
def create_sequences(X, y, timestep):
    X_seq, y_seq = [], []
    # For each sample, the input is a window of length "timestep" and the target is the value right after the window.
    for i in range(len(X) - timestep):
        X_seq.append(X[i:i + timestep])
        y_seq.append(y[i + timestep])
    return np.array(X_seq), np.array(y_seq)

timestep = 3
X_seq, y_seq = create_sequences(X_scaled, y_scaled, timestep)
print("Total sequences created:", X_seq.shape[0])

# 5. Split the data into training/validation and testing.
#    We split based on the target index of the original data (i + timestep).
train_cut = int(0.9 * len(df))
# The target indices for the sequences are from timestep to len(df)-1.
target_indices = np.arange(timestep, len(df))
train_mask = target_indices < train_cut

X_train = X_seq[train_mask]
y_train = y_seq[train_mask]
X_test = X_seq[~train_mask]
y_test = y_seq[~train_mask]

print("Training sequences:", X_train.shape[0])
print("Testing sequences:", X_test.shape[0])

# 6. Build the LSTM model.
num_features = X_scaled.shape[1]  # Number of input features from the CSV.
model = Sequential()
model.add(LSTM(10, activation='relu', input_shape=(timestep, num_features)))
model.add(Dense(3))  # Output layer: 3 neurons for the three target variables.
optimizer = Adam(learning_rate=0.001)
model.compile(optimizer=optimizer, loss='mse')

print("\nModel Summary:")
model.summary()

# 7. Train the model.
history = model.fit(X_train, y_train, epochs=10, batch_size=16, validation_split=0.1)

# 8. Make predictions on the test set.
y_pred = model.predict(X_test)

# Inverse-transform predictions and ground truth back to the original scale (for target variables only).
y_pred_inv = scaler_y.inverse_transform(y_pred)
y_test_inv = scaler_y.inverse_transform(y_test)

# 9. Define functions for error metrics.
def mean_relative_error(y_true, y_pred):
    """Mean relative error, computed as mean(|error|/|true|), with epsilon to avoid division by zero."""
    epsilon = 1e-6
    return np.mean(np.abs(y_true - y_pred) / np.maximum(np.abs(y_true), epsilon))

def mean_fractional_error(y_true, y_pred):
    """Mean fractional error, computed as mean(2|y_pred - y_true|/(|y_pred|+|y_true|))."""
    epsilon = 1e-6
    return np.mean(2 * np.abs(y_pred - y_true) / (np.abs(y_pred) + np.abs(y_true) + epsilon))

def mean_fractional_bias(y_true, y_pred):
    """Mean fractional bias, computed as mean(2*(y_pred - y_true)/( |y_pred|+|y_true| ))."""
    epsilon = 1e-6
    return np.mean(2 * (y_pred - y_true) / (np.abs(y_pred) + np.abs(y_true) + epsilon))

def mean_bias(y_true, y_pred):
    """Mean bias, computed as mean(y_pred - y_true)."""
    return np.mean(y_pred - y_true)

# 10. Compute error metrics for each target variable.
variables = target_columns
metrics = {}

for i, var in enumerate(variables):
    mse = mean_squared_error(y_test_inv[:, i], y_pred_inv[:, i])
    mae = mean_absolute_error(y_test_inv[:, i], y_pred_inv[:, i])
    mre = mean_relative_error(y_test_inv[:, i], y_pred_inv[:, i])
    mfe = mean_fractional_error(y_test_inv[:, i], y_pred_inv[:, i])
    mfb = mean_fractional_bias(y_test_inv[:, i], y_pred_inv[:, i])
    mb = mean_bias(y_test_inv[:, i], y_pred_inv[:, i])
    r2 = r2_score(y_test_inv[:, i], y_pred_inv[:, i])
    pearson_corr, _ = pearsonr(y_test_inv[:, i], y_pred_inv[:, i])
    
    metrics[var] = {
        'Mean Squared Error': mse,
        'Mean Absolute Error': mae,
        'Mean Relative Error': mre,
        'Mean Fractional Error': mfe,
        'Mean Fractional Bias': mfb,
        'Mean Bias': mb,
        'R2 Score': r2,
        'Pearson Correlation': pearson_corr
    }

# Print error metrics for each target variable.
print("\nError Metrics on the Test Set:")
for var, met in metrics.items():
    print(f"\n--- {var.upper()} ---")
    for key, value in met.items():
        print(f"{key}: {value:.4f}")

# 11. Plot comparisons for the test set.
#     For each target variable, plot the observed and predicted values.
plt.figure(figsize=(15, 5))
for i, var in enumerate(variables):
    plt.subplot(1, 3, i + 1)
    plt.plot(y_test_inv[:, i], label='Observed', marker='o')
    plt.plot(y_pred_inv[:, i], label='Predicted', marker='x')
    plt.title(f"{var.capitalize()} Comparison")
    plt.xlabel("Time Step (Test Data)")
    plt.ylabel(var)
    plt.legend()

plt.tight_layout()
plt.show()

