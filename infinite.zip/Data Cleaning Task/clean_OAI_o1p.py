
import pandas as pd

def clean_and_calculate_stats(input_csv: str, 
                              cleaned_csv: str = "cleaned_data.csv", 
                              stats_txt: str = "column_stats.txt"):
    """
    Reads a CSV file, removes rows with missing values, calculates
    mean, median, and std for each column, and outputs the results
    as described.

    Parameters:
    -----------
    input_csv: str
        Path to the input CSV file.
    cleaned_csv: str
        Path to the output CSV file (cleaned dataset).
    stats_txt: str
        Path to the output text file (statistics).
    """

    # 1. Read the CSV file
    df = pd.read_csv(input_csv)

    # 2. Remove rows with missing values
    df_clean = df.dropna()

    # 3. Calculate statistics for each column:
    #    mean, median, and std for columns that are numeric.
    #    For non-numeric columns, the statistics below will return NaN,
    #    so we can just handle numeric columns only or skip if needed.
    column_stats = {}
    for col in df_clean.columns:
        # Only calculate stats for numeric columns
        if pd.api.types.is_numeric_dtype(df_clean[col]):
            col_mean = df_clean[col].mean()
            col_median = df_clean[col].median()
            col_std = df_clean[col].std()
            column_stats[col] = (col_mean, col_median, col_std)
        else:
            # If you want to skip non-numeric columns or do something else,
            # you could put logic here. For now, we'll store None for them.
            column_stats[col] = ("N/A", "N/A", "N/A")

    # 4. Write the cleaned DataFrame to a new CSV file
    df_clean.to_csv(cleaned_csv, index=False)

    # 5. Write the calculated statistics to a text file
    with open(stats_txt, "w") as f:
        f.write("Column Statistics (mean, median, std):\n")
        for col, stats in column_stats.items():
            mean_val, median_val, std_val = stats
            f.write(f"{col} -> Mean: {mean_val}, Median: {median_val}, Std: {std_val}\n")

if __name__ == "__main__":
    # Example usage
    # Replace 'input_data.csv' with the path to your input CSV file
    clean_and_calculate_stats(input_csv="input_data.csv",
                              cleaned_csv="cleaned_data.csv",
                              stats_txt="column_stats.txt")
