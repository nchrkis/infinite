import pandas as pd

def process_csv(input_file, cleaned_file, stats_file):
    # 1. Read the CSV file into a DataFrame
    df = pd.read_csv(input_file)
    
    # 2. Clean missing values by dropping rows with any missing values
    df_clean = df.dropna()
    
    # 3. Compute statistics for each column
    stats = {}
    for col in df_clean.columns:
        # Only compute statistics for numeric columns
        if pd.api.types.is_numeric_dtype(df_clean[col]):
            mean_val = df_clean[col].mean()
            median_val = df_clean[col].median()
            std_val = df_clean[col].std()
            stats[col] = {'mean': mean_val, 'median': median_val, 'std': std_val}
        else:
            # For non-numeric columns, mark as not applicable
            stats[col] = {'mean': 'N/A', 'median': 'N/A', 'std': 'N/A'}
    
    # 4. Write the cleaned DataFrame to a new CSV file
    df_clean.to_csv(cleaned_file, index=False)
    
    # 5. Write the calculated statistics to a text file
    with open(stats_file, "w") as f:
        f.write("Column Statistics (mean, median, std):\n")
        for col, stat in stats.items():
            f.write(f"\nColumn: {col}\n")
            f.write(f"Mean: {stat['mean']}\n")
            f.write(f"Median: {stat['median']}\n")
            f.write(f"Standard Deviation: {stat['std']}\n")

if __name__ == "__main__":
    # Replace 'input.csv' with the path to your CSV file.
    process_csv("input.csv", "cleaned_data.csv", "column_stats.txt")
