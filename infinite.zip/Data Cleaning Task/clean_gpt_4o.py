import pandas as pd

# Read the CSV file
input_file = "input.csv"  # Change to your actual CSV filename
output_cleaned_file = "cleaned_data.csv"
output_stats_file = "statistics.txt"

# Load dataset
df = pd.read_csv(input_file)

# Drop rows with missing values
df_cleaned = df.dropna()

# Compute statistics
stats = df_cleaned.describe().loc[['mean', '50%', 'std']]  # '50%' represents the median

# Rename index for clarity
stats.rename(index={'50%': 'median'}, inplace=True)

# Save cleaned data to CSV
df_cleaned.to_csv(output_cleaned_file, index=False)

# Save statistics to a text file
with open(output_stats_file, "w") as f:
    f.write("Statistics for each numeric column:\n\n")
    for col in df_cleaned.select_dtypes(include=['number']).columns:
        f.write(f"{col}:\n")
        f.write(f"  Mean: {stats.loc['mean', col]:.4f}\n")
        f.write(f"  Median: {stats.loc['median', col]:.4f}\n")
        f.write(f"  Std Dev: {stats.loc['std', col]:.4f}\n\n")

print("Processing complete. Cleaned data saved as 'cleaned_data.csv', statistics saved as 'statistics.txt'.")

