
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score, mean_absolute_percentage_error
from scipy.stats import pearsonr
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
import matplotlib.pyplot as plt

# Load the data
file_path = 'path_to_data.csv'  # Replace with the correct path
data = pd.read_csv(file_path)

# Normalize the data
scaler = MinMaxScaler()
data_scaled = scaler.fit_transform(data)

# Select target variables
target_columns = ['temp', 'hum', 'windvel']
target_indices = [data.columns.get_loc(col) for col in target_columns]

# Split into training (90%) and testing (10%)
train_size = int(len(data_scaled) * 0.9)
train_data = data_scaled[:train_size]
test_data = data_scaled[train_size:]

# Prepare data for LSTM with a timestep of 3
def create_sequences(data, target_indices, timesteps=3):
    X, y = [], []
    for i in range(len(data) - timesteps):
        X.append(data[i:i + timesteps, :])  # Input features
        y.append(data[i + timesteps, target_indices])  # Target variables
    return np.array(X), np.array(y)

timesteps = 3
X_train, y_train = create_sequences(train_data, target_indices, timesteps)
X_test, y_test = create_sequences(test_data, target_indices, timesteps)

# Build the LSTM model
model = Sequential([
    LSTM(10, activation='relu', input_shape=(timesteps, data.shape[1])),
    Dense(len(target_columns))  # Output layer for target variables
])
model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001), loss='mse')

# Train the model
history = model.fit(X_train, y_train, epochs=10, batch_size=16, verbose=1)

# Make predictions
y_pred = model.predict(X_test)

# Inverse transform the predictions and actual values
y_test_inv = scaler.inverse_transform(np.hstack([np.zeros((len(y_test), data.shape[1] - len(target_columns))), y_test]))
y_pred_inv = scaler.inverse_transform(np.hstack([np.zeros((len(y_pred), data.shape[1] - len(target_columns))), y_pred]))

# Extract only the target columns for comparison
y_test_inv = y_test_inv[:, target_indices]
y_pred_inv = y_pred_inv[:, target_indices]

# Error metrics
mse = mean_squared_error(y_test_inv, y_pred_inv)
mae = mean_absolute_error(y_test_inv, y_pred_inv)
r2 = r2_score(y_test_inv, y_pred_inv)
mape = mean_absolute_percentage_error(y_test_inv, y_pred_inv)
pearson_corr, _ = pearsonr(y_test_inv.flatten(), y_pred_inv.flatten())

# Results summary
metrics = {
    "Mean Squared Error (MSE)": mse,
    "Mean Absolute Error (MAE)": mae,
    "Mean Absolute Percentage Error (MAPE)": mape,
    "R2 Score": r2,
    "Pearson Correlation Coefficient": pearson_corr
}

# Print metrics
for metric, value in metrics.items():
    print(f"{metric}: {value:.4f}")

# Plotting actual vs predicted for test set
plt.figure(figsize=(12, 8))
plt.plot(y_test_inv[:, 0], label="Actual Temperature")
plt.plot(y_pred_inv[:, 0], label="Predicted Temperature", linestyle='dashed')
plt.plot(y_test_inv[:, 1], label="Actual Humidity")
plt.plot(y_pred_inv[:, 1], label="Predicted Humidity", linestyle='dashed')
plt.plot(y_test_inv[:, 2], label="Actual Wind Velocity")
plt.plot(y_pred_inv[:, 2], label="Predicted Wind Velocity", linestyle='dashed')
plt.title("Actual vs Predicted Values (Test Set)")
plt.xlabel("Time")
plt.ylabel("Values")
plt.legend()
plt.grid(True)
plt.show()


