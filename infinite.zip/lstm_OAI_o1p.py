import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import scipy.stats as stats

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.optimizers import Adam

# -----------------------------------------------------------------------
# 1. LOAD THE CSV
# -----------------------------------------------------------------------
# Assumptions:
# - Your CSV has headers, including "temp", "hum", "windvel", plus other columns.
# - If there is a date or non-numeric column, drop or skip it before scaling.
#   Below, we assume you want to keep all numeric columns as inputs.

df = pd.read_csv("path_to_data.csv")

# Example: if there's a "date" column you want to drop because it's non-numeric:
# if "date" in df.columns:
#     df.drop(columns=["date"], inplace=True)

# Drop rows with any missing values in the columns you care about
df.dropna(inplace=True)

print("Columns in the CSV:", df.columns)
print(df.head())

# -----------------------------------------------------------------------
# 2. FIND THE INDEX OF THE TARGET COLUMNS
# -----------------------------------------------------------------------
# The CSV presumably has "temp", "hum", "windvel" among others.
target_cols = ["temp", "hum", "windvel"]

# Make sure these columns exist
for col in target_cols:
    if col not in df.columns:
        raise ValueError(f"Column '{col}' not found in CSV!")

# We will predict only these 3 columns. 
# But our inputs will be ALL columns in df (except we might drop any obviously
# non-numeric columns above if needed).

input_cols = list(df.columns)  # all columns as inputs
num_input_features = len(input_cols)

# Indices for the 3 target columns (in the same order as target_cols)
target_indices = [df.columns.get_loc(col) for col in target_cols]

# -----------------------------------------------------------------------
# 3. SCALE THE DATA
# -----------------------------------------------------------------------
scaler = MinMaxScaler()
data_all = df.values  # shape: (num_samples, num_input_features)

# Fit scaler on entire data (all columns) so model sees them as inputs
data_all_scaled = scaler.fit_transform(data_all)  # same shape

# -----------------------------------------------------------------------
# 4. SPLIT INTO TRAIN AND TEST (TIMEWISE) & CREATE SEQUENCES
# -----------------------------------------------------------------------
split_index = int(len(data_all_scaled) * 0.9)
train_data = data_all_scaled[:split_index]
test_data  = data_all_scaled[split_index:]

print("Train data shape:", train_data.shape)  # (num_train, num_features)
print("Test data shape:", test_data.shape)    # (num_test, num_features)

timesteps = 3

def create_sequences(dataset, timesteps=3):
    """
    Returns:
      X: shape (num_samples - timesteps, timesteps, num_features)
      Y: shape (num_samples - timesteps, 3)  for our 3 targets
    """
    X, Y = [], []
    for i in range(len(dataset) - timesteps):
        # All columns go into X
        seq_x = dataset[i:i+timesteps, :]  
        # Only the 3 target columns for Y (the next row after i+timesteps-1)
        seq_y = dataset[i+timesteps, target_indices]  
        
        X.append(seq_x)
        Y.append(seq_y)
    return np.array(X), np.array(Y)

X_train, y_train = create_sequences(train_data, timesteps=timesteps)
X_test, y_test = create_sequences(test_data, timesteps=timesteps)

print("X_train shape:", X_train.shape)  # (num_train_samples - 3, 3, num_features)
print("y_train shape:", y_train.shape)  # (num_train_samples - 3, 3)
print("X_test shape:", X_test.shape)
print("y_test shape:", y_test.shape)

# -----------------------------------------------------------------------
# 5. BUILD THE LSTM MODEL
# -----------------------------------------------------------------------
model = Sequential()
# Input shape: (timesteps=3, num_input_features)
model.add(LSTM(10, activation='relu', input_shape=(timesteps, num_input_features)))
# Output shape: 3 (for temp, hum, windvel)
model.add(Dense(3))

optimizer = Adam(learning_rate=0.001)
model.compile(optimizer=optimizer, loss='mse')
model.summary()

# -----------------------------------------------------------------------
# 6. TRAIN THE MODEL
# -----------------------------------------------------------------------
history = model.fit(
    X_train, y_train,
    epochs=10,
    batch_size=16,
    validation_split=0.1,  # 10% of train data for validation
    verbose=1
)

# -----------------------------------------------------------------------
# 7. MAKE PREDICTIONS
# -----------------------------------------------------------------------
y_pred = model.predict(X_test)  # shape: (num_test_samples, 3)

# -----------------------------------------------------------------------
# 8. PARTIAL INVERSE TRANSFORM FOR THE 3 TARGETS ONLY
# -----------------------------------------------------------------------
# Because we scaled *all* features together, if we just do
# scaler.inverse_transform(y_pred) => error, the scaler expects a shape
# matching the original number of features.
#
# Instead, we can insert the predicted 3 columns into a dummy array of
# shape (N, num_input_features), call inverse_transform, then take
# the relevant columns back out.
#
# Let’s define a small helper function:
def partial_inverse_transform(scaler, y, target_indices):
    """
    y: shape (N, len(target_indices)) 
    target_indices: indices of the columns that correspond to 'y' 
                    in the original data.
    
    Returns an array (N, len(target_indices)) in the original scale.
    """
    # Create a placeholder of shape (N, total_features)
    full_shape = (y.shape[0], scaler.n_features_in_)
    full_data = np.zeros(full_shape, dtype=np.float32)
    
    # Place the predictions into the correct columns
    full_data[:, target_indices] = y
    
    # Apply inverse scaling
    full_data_inv = scaler.inverse_transform(full_data)
    
    # Return only the 3 columns of interest
    return full_data_inv[:, target_indices]

# Invert test labels
y_test_inverted = partial_inverse_transform(scaler, y_test, target_indices)

# Invert predictions
y_pred_inverted = partial_inverse_transform(scaler, y_pred, target_indices)

# -----------------------------------------------------------------------
# 9. DEFINE CUSTOM METRICS
# -----------------------------------------------------------------------
def mean_relative_error(y_true, y_pred):
    """
    MRE = mean(|pred - true| / |true|)*100
    """
    return np.mean(np.abs(y_pred - y_true) / np.clip(np.abs(y_true), 1e-9, None)) * 100

def mean_fractional_error(y_true, y_pred):
    """
    MFE = mean( |pred - true| / ((pred + true)/2) )
    """
    return np.mean(np.abs(y_pred - y_true) / np.clip((y_pred + y_true)/2, 1e-9, None))

def mean_fractional_bias(y_true, y_pred):
    """
    MFB = mean( (pred - true) / ((pred + true)/2) )
    """
    return np.mean((y_pred - y_true) / np.clip((y_pred + y_true)/2, 1e-9, None))

def mean_bias(y_true, y_pred):
    """
    MB = mean( pred - true )
    """
    return np.mean(y_pred - y_true)

# -----------------------------------------------------------------------
# 10. EVALUATE METRICS (temp, hum, windvel)
# -----------------------------------------------------------------------
variables = ["temp", "hum", "windvel"]
for i in range(3):
    true_vals = y_test_inverted[:, i]
    pred_vals = y_pred_inverted[:, i]
    
    mse = mean_squared_error(true_vals, pred_vals)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(true_vals, pred_vals)
    mre = mean_relative_error(true_vals, pred_vals)
    mfe = mean_fractional_error(true_vals, pred_vals)
    mfb = mean_fractional_bias(true_vals, pred_vals)
    mb = mean_bias(true_vals, pred_vals)
    r2 = r2_score(true_vals, pred_vals)
    
    # Pearson correlation
    pearson_corr, _ = stats.pearsonr(true_vals, pred_vals)
    
    print(f"\n=== Metrics for {variables[i]} ===")
    print(f"MSE:   {mse:.4f}")
    print(f"RMSE:  {rmse:.4f}")
    print(f"MAE:   {mae:.4f}")
    print(f"MRE (%): {mre:.2f}")
    print(f"MFE:   {mfe:.4f}")
    print(f"MFB:   {mfb:.4f}")
    print(f"MB:    {mb:.4f}")
    print(f"R^2:   {r2:.4f}")
    print(f"Pearson Corr: {pearson_corr:.4f}")

# -----------------------------------------------------------------------
# 11. PLOT RESULTS
# -----------------------------------------------------------------------
plt.figure(figsize=(15, 5))
for i, var_name in enumerate(variables):
    plt.subplot(1, 3, i+1)
    plt.plot(y_test_inverted[:, i], label='True '+var_name, color='blue')
    plt.plot(y_pred_inverted[:, i], label='Pred '+var_name, color='red')
    plt.title(f"Comparison: {var_name}")
    plt.legend()

plt.tight_layout()
plt.show()


